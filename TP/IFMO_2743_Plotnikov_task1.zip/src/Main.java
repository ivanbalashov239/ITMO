public class Main {
    public static void main(String[] args) {
        Benchmark sortedHeapTest = new Benchmark("SortedHeap", 10000, 12345);
        Benchmark binHeapTest = new Benchmark("BinHeap", 10000, 12345);

    }
}
